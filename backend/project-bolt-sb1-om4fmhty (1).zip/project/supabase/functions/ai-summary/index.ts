const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ThreatInput {
  category: string;
  severity: string;
  evidence: string;
}

interface SummaryRequest {
  caseLabel: string;
  summary: string;
  eventCount: number;
  sessionCount: number;
  threats: ThreatInput[];
  tlsFindings: Array<{ server: string; version: string; cipher: string; state: string; details: string }>;
  starttlsFindings: Array<{ server: string; port: number; supported: boolean; forced: boolean; state: string; details: string }>;
  dnsRecords: Array<{ query: string; type: string; answer: string; state: string; details: string }>;
  certificates: Array<{ hostname: string; issuer: string; subject: string; state: string; details: string }>;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body: SummaryRequest = await req.json();

    const critical = body.threats.filter((t) => t.severity === "Critical");
    const high = body.threats.filter((t) => t.severity === "High");
    const medium = body.threats.filter((t) => t.severity === "Medium");

    const lines: string[] = [];

    lines.push(
      `Case ${body.caseLabel} analysis identified ${body.eventCount} network events across ${body.sessionCount} sessions.`
    );
    lines.push("");

    if (body.threats.length === 0) {
      lines.push(
        "No significant security threats were detected in the captured traffic. The mail and TLS configurations appear to be operating within expected security parameters."
      );
    } else {
      lines.push(
        `The investigation surfaced ${body.threats.length} security finding(s): ${critical.length} critical, ${high.length} high, and ${medium.length} medium severity.`
      );
      lines.push("");

      if (critical.length > 0) {
        lines.push("CRITICAL FINDINGS:");
        for (const t of critical) {
          lines.push(`- ${t.category}: ${t.evidence}`);
        }
        lines.push("");
      }

      if (high.length > 0) {
        lines.push("HIGH SEVERITY FINDINGS:");
        for (const t of high) {
          lines.push(`- ${t.category}: ${t.evidence}`);
        }
        lines.push("");
      }

      if (medium.length > 0) {
        lines.push("MEDIUM SEVERITY FINDINGS:");
        for (const t of medium) {
          lines.push(`- ${t.category}: ${t.evidence}`);
        }
        lines.push("");
      }

      lines.push("SUMMARY ASSESSMENT:");
      if (critical.length > 0) {
        lines.push(
          "This capture shows evidence of active compromise with multiple critical-severity threats. Immediate incident response is recommended: isolate affected hosts, rotate exposed credentials, and block identified malicious infrastructure."
        );
      } else if (high.length > 0) {
        lines.push(
          "This capture reveals significant security weaknesses that should be remediated promptly. While no active compromise is confirmed, the configuration issues create substantial risk of future attack."
        );
      } else {
        lines.push(
          "This capture shows minor security weaknesses. Remediation of medium-severity findings will improve the overall security posture."
        );
      }
    }

    const summary = lines.join("\n");

    return new Response(JSON.stringify({ summary }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
