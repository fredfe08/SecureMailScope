import type { EvidenceState } from '@/evidence';

interface IconProps {
  name: string;
  className?: string;
  size?: number;
}

export function Icon({ name, className = '', size = 18 }: IconProps) {
  const paths: Record<string, string> = {
    workspace: 'M3 3h7v7H3V3zm11 0h7v7h-7V3zM3 14h7v7H3v-7zm11 0h7v7h-7v-7z',
    investigation: 'M11 2a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 4a5 5 0 0 1 5 5h-2a3 3 0 0 0-3-3V6z',
    sessions: 'M4 4h16v4H4V4zm0 6h16v4H4v-4zm0 6h16v4H4v-4z',
    starttls: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z',
    tls: 'M12 1l9 4v6c0 5.55-3.84 10.74-9 12-5.16-1.26-9-6.45-9-12V5l9-4zm-1 6v2h2V7h-2zm0 4v6h2v-6h-2z',
    evidence: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
    threat: 'M12 2L2 22h20L12 2zm0 4l7 12H5l7-12zm-1 4v4h2v-4h-2zm0 5v2h2v-2h-2z',
    ai: 'M12 2a3 3 0 0 1 3 3 3 3 0 0 1 3 3 3 3 0 0 1-1 2.24V15a3 3 0 0 1-3 3h-.76A3 3 0 0 1 12 22a3 3 0 0 1-2.24-1H9a3 3 0 0 1-3-3v-2.76A3 3 0 0 1 5 11a3 3 0 0 1 3-3 3 3 0 0 1 3-3 3 3 0 0 1 3-3z',
    download: 'M12 3v12m0 0l-4-4m4 4l4-4M5 21h14',
    upload: 'M12 21V9m0 0l-4 4m4-4l4 4M5 3h14',
    shield: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z',
    alert: 'M12 2L2 22h20L12 2zm0 6v6h2V8h-2zm0 8v2h2v-2h-2z',
    check: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z',
    x: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z',
    clock: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 2a8 8 0 0 1 8 8h-2a6 6 0 0 0-6-6V4z',
    server: 'M4 4h16v6H4V4zm0 10h16v6H4v-6zm2 2v2h2v-2H6zm0-10v2h2V6H6z',
    lock: 'M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5zm-3 8V6a3 3 0 0 1 6 0v3H9z',
    globe: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-1 17.93A8 8 0 0 1 4.07 13H7c.1 2.28.6 4.2 1.34 5.93zm0-15.86C9.6 5.82 9.1 7.74 9 10H4.07A8 8 0 0 1 11 4.07zM13 4.07A8 8 0 0 1 19.93 11H17c-.1-2.28-.6-4.2-1.34-5.93zm0 15.86c.74-1.73 1.24-3.65 1.34-5.93h2.93A8 8 0 0 1 13 19.93z',
    file: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z',
    search: 'M15.5 14h-.79l-.28-.27a6.5 6.5 0 1 0-.7.7l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0A4.5 4.5 0 1 1 14 9.5 4.5 4.5 0 0 1 9.5 14z',
    refresh: 'M17.65 6.35A7.96 7.96 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
  };

  const d = paths[name] || paths.file;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={name === 'threat' ? 'currentColor' : 'none'}
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d={d} />
    </svg>
  );
}

interface PanelProps {
  children: React.ReactNode;
  title?: string;
  className?: string;
  actions?: React.ReactNode;
}

export function Panel({ children, title, className = '', actions }: PanelProps) {
  return (
    <div className={`panel ${className}`}>
      {title && (
        <div className="panel-header">
          <h3 className="panel-title">{title}</h3>
          {actions && <div className="panel-actions">{actions}</div>}
        </div>
      )}
      <div className="panel-body">{children}</div>
    </div>
  );
}

interface SectionHeadingProps {
  title: string;
  subtitle?: string;
  icon?: string;
}

export function SectionHeading({ title, subtitle, icon }: SectionHeadingProps) {
  return (
    <div className="section-heading">
      {icon && (
        <span className="section-heading-icon">
          <Icon name={icon} size={20} />
        </span>
      )}
      <div>
        <h2 className="section-heading-title">{title}</h2>
        {subtitle && <p className="section-heading-subtitle">{subtitle}</p>}
      </div>
    </div>
  );
}

interface StateMarkProps {
  state: EvidenceState;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function StateMark({ state, label, size = 'md' }: StateMarkProps) {
  const labels: Record<EvidenceState, string> = {
    verified: 'Verified',
    failed: 'Failed',
    warning: 'Warning',
    info: 'Info',
    suspicious: 'Suspicious',
    critical: 'Critical',
    unknown: 'Unknown',
  };
  return (
    <span className={`state-mark state-${state} state-mark-${size}`}>
      <span className="state-mark-dot" />
      <span className="state-mark-label">{label || labels[state]}</span>
    </span>
  );
}

interface ProtocolMarkProps {
  protocol: string;
}

export function ProtocolMark({ protocol }: ProtocolMarkProps) {
  return <span className={`protocol-mark proto-${protocol.toLowerCase()}`}>{protocol}</span>;
}

export function Badge({ state, children }: { state: EvidenceState; children: React.ReactNode }) {
  return <span className={`badge badge-${state}`}>{children}</span>;
}
