import { Panel, SectionHeading, StateMark } from '@/components';
import type { EvidenceReport } from '@/evidence';

export function Starttls({ report }: { report: EvidenceReport }) {
  return (
    <div className="screen screen-starttls">
      <SectionHeading
        title="STARTTLS"
        subtitle="STARTTLS capability and enforcement findings"
        icon="starttls"
      />

      <Panel title="STARTTLS Findings" className="starttls-panel">
        <div className="findings-table">
          <div className="findings-row findings-header">
            <span>Server</span>
            <span>Port</span>
            <span>Supported</span>
            <span>Forced</span>
            <span>State</span>
            <span>Details</span>
          </div>
          {report.starttlsFindings.map((f) => (
            <div key={f.id} className="findings-row">
              <span className="findings-server">{f.server}</span>
              <span className="findings-port">{f.port}</span>
              <span className="findings-bool">
                {f.supported ? (
                  <StateMark state="verified" label="Yes" size="sm" />
                ) : (
                  <StateMark state="critical" label="No" size="sm" />
                )}
              </span>
              <span className="findings-bool">
                {f.forced ? (
                  <StateMark state="verified" label="Yes" size="sm" />
                ) : (
                  <StateMark state="warning" label="No" size="sm" />
                )}
              </span>
              <span><StateMark state={f.state} size="sm" /></span>
              <span className="findings-details">{f.details}</span>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="Recommendations" className="starttls-recommendations">
        <ul className="recommendation-list">
          <li>
            <StateMark state="critical" label="Critical" size="sm" />
            Enforce STARTTLS on all SMTP port 25 connections to prevent credential exposure
          </li>
          <li>
            <StateMark state="warning" label="Warning" size="sm" />
            Configure servers to reject connections that do not upgrade to TLS
          </li>
          <li>
            <StateMark state="info" label="Info" size="sm" />
            Consider migrating to SMTPS (port 465) for implicit TLS where possible
          </li>
        </ul>
      </Panel>
    </div>
  );
}
