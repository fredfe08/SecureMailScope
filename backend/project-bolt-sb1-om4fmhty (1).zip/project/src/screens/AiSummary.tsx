import { useEffect, useState } from 'react';
import { Panel, SectionHeading, StateMark, Icon } from '@/components';
import { getAISummary } from '@/lib/aiSummary';
import type { EvidenceReport } from '@/evidence';
import type { ThreatFinding } from '@/lib/fraudDetection';

interface AiSummaryProps {
  report: EvidenceReport;
  threats: ThreatFinding[];
}

export function AiSummary({ report, threats }: AiSummaryProps) {
  const [summary, setSummary] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    getAISummary(report, threats)
      .then((result) => {
        if (!cancelled) {
          setSummary(result);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : String(err));
          setLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [report, threats]);

  return (
    <div className="screen screen-ai-summary">
      <SectionHeading
        title="AI Summary"
        subtitle="Plain-English analysis of the investigation findings"
        icon="ai"
      />

      <Panel
        title="Investigation Summary"
        className="ai-summary-panel"
        actions={
          loading ? (
            <StateMark state="info" label="Generating..." />
          ) : error ? (
            <StateMark state="critical" label="Error" />
          ) : (
            <StateMark state="verified" label="Complete" />
          )
        }
      >
        {loading && (
          <div className="ai-summary-loading">
            <Icon name="refresh" size={24} className="spin" />
            <p>Analyzing evidence and generating summary...</p>
          </div>
        )}

        {error && !loading && (
          <div className="ai-summary-error">
            <StateMark state="critical" label="Error" />
            <p>{error}</p>
          </div>
        )}

        {summary && !loading && !error && (
          <div className="ai-summary-content">
            {summary.split('\n').map((line, i) => {
              const trimmed = line.trim();
              if (!trimmed) return <div key={i} className="ai-summary-spacer" />;
              if (trimmed.endsWith(':') || /^[A-Z\s]+$/.test(trimmed)) {
                return <h4 key={i} className="ai-summary-heading">{trimmed}</h4>;
              }
              if (trimmed.startsWith('•')) {
                return <p key={i} className="ai-summary-bullet">{trimmed}</p>;
              }
              return <p key={i} className="ai-summary-paragraph">{trimmed}</p>;
            })}
          </div>
        )}
      </Panel>

      <Panel title="Summary Metadata" className="ai-summary-meta">
        <div className="meta-grid">
          <div className="meta-row">
            <span className="meta-label">Case</span>
            <span className="meta-value">{report.caseLabel}</span>
          </div>
          <div className="meta-row">
            <span className="meta-label">Events Analyzed</span>
            <span className="meta-value">{report.events.length}</span>
          </div>
          <div className="meta-row">
            <span className="meta-label">Threats Found</span>
            <span className="meta-value">{threats.length}</span>
          </div>
          <div className="meta-row">
            <span className="meta-label">Generated</span>
            <span className="meta-value">{new Date().toLocaleString()}</span>
          </div>
        </div>
      </Panel>
    </div>
  );
}
