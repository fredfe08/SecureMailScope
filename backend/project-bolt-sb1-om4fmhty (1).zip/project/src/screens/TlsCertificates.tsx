import { Panel, SectionHeading, StateMark } from '@/components';
import type { EvidenceReport } from '@/evidence';

export function TlsCertificates({ report }: { report: EvidenceReport }) {
  return (
    <div className="screen screen-tls">
      <SectionHeading
        title="TLS & Certificates"
        subtitle="TLS negotiation details and certificate analysis"
        icon="tls"
      />

      <Panel title="TLS Findings" className="tls-findings-panel">
        <div className="findings-table">
          <div className="findings-row findings-header">
            <span>Server</span>
            <span>Version</span>
            <span>Cipher</span>
            <span>Key Exchange</span>
            <span>State</span>
            <span>Details</span>
          </div>
          {report.tlsFindings.map((f) => (
            <div key={f.id} className="findings-row">
              <span className="findings-server">{f.server}</span>
              <span className="findings-version">{f.version}</span>
              <span className="findings-cipher">{f.cipher}</span>
              <span className="findings-kex">{f.keyExchange}</span>
              <span><StateMark state={f.state} size="sm" /></span>
              <span className="findings-details">{f.details}</span>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="Certificate Analysis" className="cert-panel">
        <div className="cert-grid">
          {report.certificates.map((c) => (
            <div key={c.id} className="cert-card">
              <div className="cert-card-header">
                <span className="cert-hostname">{c.hostname}</span>
                <StateMark state={c.state} size="sm" />
              </div>
              <div className="cert-card-body">
                <div className="cert-row">
                  <span className="cert-label">Issuer</span>
                  <span className="cert-value">{c.issuer}</span>
                </div>
                <div className="cert-row">
                  <span className="cert-label">Subject</span>
                  <span className="cert-value">{c.subject}</span>
                </div>
                <div className="cert-row">
                  <span className="cert-label">Validity</span>
                  <span className="cert-value">{c.validFrom} → {c.validTo}</span>
                </div>
                <div className="cert-row">
                  <span className="cert-label">Key</span>
                  <span className="cert-value">{c.keyType} {c.keyLength} bit</span>
                </div>
                <div className="cert-row">
                  <span className="cert-label">Signature</span>
                  <span className="cert-value">{c.signatureAlgorithm}</span>
                </div>
                <div className="cert-row">
                  <span className="cert-label">SAN</span>
                  <span className="cert-value">{c.san.join(', ') || '—'}</span>
                </div>
                <p className="cert-details">{c.details}</p>
              </div>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}
