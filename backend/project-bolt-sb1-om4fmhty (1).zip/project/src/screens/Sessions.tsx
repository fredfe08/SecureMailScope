import { useState } from 'react';
import { Panel, SectionHeading, StateMark, ProtocolMark } from '@/components';
import { formatNumber } from '@/evidence';
import type { EvidenceReport, Session } from '@/evidence';

export function Sessions({ report }: { report: EvidenceReport }) {
  const [selected, setSelected] = useState<Session | null>(null);

  return (
    <div className="screen screen-sessions">
      <SectionHeading
        title="Sessions"
        subtitle="Network sessions extracted from the capture"
        icon="sessions"
      />

      <div className="sessions-layout">
        <div className="sessions-list">
          <Panel title={`Captured Sessions (${report.sessions.length})`}>
            <div className="session-list-items">
              {report.sessions.map((s) => (
                <button
                  key={s.id}
                  className={`session-list-item ${selected?.id === s.id ? 'selected' : ''}`}
                  onClick={() => setSelected(s)}
                >
                  <div className="session-list-item-top">
                    <ProtocolMark protocol={s.protocol} />
                    <StateMark state={s.state} size="sm" />
                  </div>
                  <div className="session-list-item-meta">
                    <span className="session-src">{s.source}</span>
                    <span className="session-arrow">→</span>
                    <span className="session-dst">{s.destination}</span>
                  </div>
                  <div className="session-list-item-stats">
                    <span>{s.eventCount} events</span>
                    <span>{formatNumber(s.bytesTransferred)}</span>
                  </div>
                </button>
              ))}
            </div>
          </Panel>
        </div>

        <div className="sessions-detail">
          {selected ? (
            <Panel title={`Session ${selected.id}`} actions={<StateMark state={selected.state} />}>
              <div className="session-detail-grid">
                <div className="detail-row">
                  <span className="detail-label">Source</span>
                  <span className="detail-value">{selected.source}</span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Destination</span>
                  <span className="detail-value">{selected.destination}</span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Protocol</span>
                  <span className="detail-value"><ProtocolMark protocol={selected.protocol} /></span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Port</span>
                  <span className="detail-value">{selected.port}</span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Start</span>
                  <span className="detail-value">{new Date(selected.startTime).toLocaleString()}</span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">End</span>
                  <span className="detail-value">{new Date(selected.endTime).toLocaleString()}</span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Events</span>
                  <span className="detail-value">{selected.eventCount}</span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Data</span>
                  <span className="detail-value">{formatNumber(selected.bytesTransferred)}</span>
                </div>
              </div>

              <h4 className="detail-subheading">Events in this session</h4>
              <div className="session-events">
                {report.events
                  .filter(
                    (e) =>
                      e.source === selected.source ||
                      e.destination === selected.destination ||
                      e.destination.startsWith(selected.destination.split(':')[0])
                  )
                  .map((e) => (
                    <div key={e.id} className="event-row">
                      <span className="event-time">{new Date(e.timestamp).toLocaleTimeString()}</span>
                      <StateMark state={e.state} size="sm" />
                      <ProtocolMark protocol={e.protocol} />
                      <span className="event-msg">{e.message}</span>
                      {e.details && <span className="event-details">{e.details}</span>}
                    </div>
                  ))}
              </div>
            </Panel>
          ) : (
            <Panel title="Session Details">
              <p className="empty-state">Select a session to view details</p>
            </Panel>
          )}
        </div>
      </div>
    </div>
  );
}
