import { Panel, SectionHeading, StateMark, Icon } from '@/components';
import { formatNumber } from '@/evidence';
import type { EvidenceReport } from '@/evidence';
import { generatePdfReport } from '@/lib/pdfReport';
import type { ThreatFinding } from '@/lib/fraudDetection';
import { detectThreats } from '@/lib/fraudDetection';

interface InvestigationProps {
  report: EvidenceReport;
  threats: ThreatFinding[];
  aiSummary: string | null;
}

export function Investigation({ report, threats, aiSummary }: InvestigationProps) {
  const criticalCount = report.events.filter((e) => e.state === 'critical').length;
  const warningCount = report.events.filter((e) => e.state === 'warning').length;
  const suspiciousCount = report.events.filter((e) => e.state === 'suspicious').length;
  const verifiedCount = report.events.filter((e) => e.state === 'verified').length;

  return (
    <div className="screen screen-investigation">
      <SectionHeading
        title="Investigation"
        subtitle="Overview of captured evidence and analysis findings"
        icon="investigation"
      />

      <div className="investigation-actions">
        <button
          className="btn btn-primary"
          onClick={() => generatePdfReport(report, threats, aiSummary)}
        >
          <Icon name="download" size={16} />
          Download Report (PDF)
        </button>
      </div>

      <Panel title="Case Summary" className="investigation-summary">
        <div className="case-header">
          <div className="case-label">{report.caseLabel}</div>
          <div className="case-title">{report.caseTitle}</div>
        </div>
        <p className="case-summary-text">{report.summary}</p>
        <div className="case-meta">
          <span>
            <Icon name="clock" size={14} /> Generated: {new Date(report.generatedAt).toLocaleString()}
          </span>
          <span>
            <Icon name="file" size={14} /> Source: {report.sourceFile}
          </span>
          <span>
            <Icon name="search" size={14} /> Analyst: {report.analyst}
          </span>
        </div>
      </Panel>

      <div className="stat-grid stat-grid-wide">
        <div className="stat-item stat-card">
          <span className="stat-label">Total Events</span>
          <span className="stat-value stat-value-lg">{report.events.length}</span>
        </div>
        <div className="stat-item stat-card stat-card-critical">
          <span className="stat-label">Critical</span>
          <span className="stat-value stat-value-lg">{criticalCount}</span>
        </div>
        <div className="stat-item stat-card stat-card-warning">
          <span className="stat-label">Warnings</span>
          <span className="stat-value stat-value-lg">{warningCount}</span>
        </div>
        <div className="stat-item stat-card stat-card-suspicious">
          <span className="stat-label">Suspicious</span>
          <span className="stat-value stat-value-lg">{suspiciousCount}</span>
        </div>
        <div className="stat-item stat-card stat-card-verified">
          <span className="stat-label">Verified</span>
          <span className="stat-value stat-value-lg">{verifiedCount}</span>
        </div>
      </div>

      <Panel title="Threat Detection Summary" className="investigation-threats">
        {threats.length === 0 ? (
          <StateMark state="verified" label="No threats detected" />
        ) : (
          <div className="threat-summary-list">
            {threats.map((t) => (
              <div key={t.category} className="threat-summary-row">
                <StateMark state={severityToState(t.severity)} label={t.severity} size="sm" />
                <span className="threat-summary-category">{t.category}</span>
                <span className="threat-summary-evidence">{t.evidence}</span>
              </div>
            ))}
          </div>
        )}
      </Panel>

      <Panel title="Protocol Distribution" className="investigation-protocols">
        <ProtocolDistribution events={report.events} />
      </Panel>
    </div>
  );
}

function severityToState(sev: string): 'critical' | 'warning' | 'suspicious' | 'verified' | 'info' {
  switch (sev) {
    case 'Critical': return 'critical';
    case 'High': return 'critical';
    case 'Medium': return 'warning';
    case 'Low': return 'info';
    default: return 'info';
  }
}

function ProtocolDistribution({ events }: { events: EvidenceReport['events'] }) {
  const counts: Record<string, number> = {};
  events.forEach((e) => {
    counts[e.protocol] = (counts[e.protocol] || 0) + 1;
  });
  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  const max = sorted[0]?.[1] || 1;

  return (
    <div className="proto-dist">
      {sorted.map(([proto, count]) => (
        <div key={proto} className="proto-dist-row">
          <span className="proto-dist-label">{proto}</span>
          <div className="proto-dist-bar-container">
            <div
              className={`proto-dist-bar proto-dist-${proto.toLowerCase()}`}
              style={{ width: `${(count / max) * 100}%` }}
            />
          </div>
          <span className="proto-dist-count">{count}</span>
        </div>
      ))}
    </div>
  );
}
