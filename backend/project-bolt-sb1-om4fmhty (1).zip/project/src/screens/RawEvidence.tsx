import { useState } from 'react';
import { Panel, SectionHeading, StateMark, ProtocolMark } from '@/components';
import type { EvidenceReport, EvidenceState } from '@/evidence';

const STATE_FILTERS: EvidenceState[] = ['critical', 'warning', 'suspicious', 'verified', 'info'];

export function RawEvidence({ report }: { report: EvidenceReport }) {
  const [filter, setFilter] = useState<EvidenceState | null>(null);
  const [search, setSearch] = useState('');

  const filtered = report.events.filter((e) => {
    if (filter && e.state !== filter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        e.message.toLowerCase().includes(q) ||
        e.source.toLowerCase().includes(q) ||
        e.destination.toLowerCase().includes(q) ||
        (e.details || '').toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="screen screen-evidence">
      <SectionHeading
        title="Raw Evidence"
        subtitle="All captured network events in chronological order"
        icon="evidence"
      />

      <Panel
        title={`Events (${filtered.length})`}
        className="evidence-panel"
        actions={
          <div className="evidence-filters">
            <input
              type="text"
              placeholder="Search events..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="evidence-search"
            />
            <div className="evidence-state-filters">
              {STATE_FILTERS.map((s) => (
                <button
                  key={s}
                  className={`filter-chip ${filter === s ? 'active' : ''}`}
                  onClick={() => setFilter(filter === s ? null : s)}
                >
                  <StateMark state={s} size="sm" />
                </button>
              ))}
              {filter && (
                <button className="filter-chip filter-clear" onClick={() => setFilter(null)}>
                  Clear
                </button>
              )}
            </div>
          </div>
        }
      >
        <div className="evidence-table">
          <div className="evidence-row evidence-row-header">
            <span>Time</span>
            <span>Source</span>
            <span>Destination</span>
            <span>Proto</span>
            <span>State</span>
            <span>Message</span>
            <span>Bytes</span>
          </div>
          {filtered.map((e) => (
            <div key={e.id} className="evidence-row">
              <span className="ev-time">{new Date(e.timestamp).toLocaleTimeString()}</span>
              <span className="ev-src">{e.source}</span>
              <span className="ev-dst">{e.destination}</span>
              <span><ProtocolMark protocol={e.protocol} /></span>
              <span><StateMark state={e.state} size="sm" /></span>
              <span className="ev-msg">
                {e.message}
                {e.details && <span className="ev-details">{e.details}</span>}
              </span>
              <span className="ev-bytes">{e.bytes ? e.bytes.toLocaleString() : '—'}</span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}
