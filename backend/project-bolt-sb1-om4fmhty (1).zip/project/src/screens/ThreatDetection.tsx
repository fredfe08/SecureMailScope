import { useState } from 'react';
import { Panel, SectionHeading, StateMark, Icon } from '@/components';
import type { ThreatFinding } from '@/lib/fraudDetection';

interface ThreatDetectionProps {
  threats: ThreatFinding[];
}

const SEVERITY_ORDER: Record<string, number> = {
  Critical: 0,
  High: 1,
  Medium: 2,
  Low: 3,
};

function severityToState(sev: string): 'critical' | 'warning' | 'suspicious' | 'info' {
  switch (sev) {
    case 'Critical': return 'critical';
    case 'High': return 'critical';
    case 'Medium': return 'warning';
    case 'Low': return 'info';
    default: return 'info';
  }
}

export function ThreatDetection({ threats }: ThreatDetectionProps) {
  const [filter, setFilter] = useState<string | null>(null);

  const categories = Array.from(new Set(threats.map((t) => t.category)));
  const filtered = filter ? threats.filter((t) => t.category === filter) : threats;
  const sorted = [...filtered].sort((a, b) => (SEVERITY_ORDER[a.severity] || 99) - (SEVERITY_ORDER[b.severity] || 99));

  const criticalCount = threats.filter((t) => t.severity === 'Critical').length;
  const highCount = threats.filter((t) => t.severity === 'High').length;
  const mediumCount = threats.filter((t) => t.severity === 'Medium').length;
  const lowCount = threats.filter((t) => t.severity === 'Low').length;

  return (
    <div className="screen screen-threat">
      <SectionHeading
        title="Threat Detection"
        subtitle="Automated threat analysis of captured network evidence"
        icon="threat"
      />

      <div className="stat-grid stat-grid-wide">
        <div className="stat-item stat-card stat-card-critical">
          <span className="stat-label">Critical</span>
          <span className="stat-value stat-value-lg">{criticalCount}</span>
        </div>
        <div className="stat-item stat-card stat-card-warning">
          <span className="stat-label">High</span>
          <span className="stat-value stat-value-lg">{highCount}</span>
        </div>
        <div className="stat-item stat-card stat-card-suspicious">
          <span className="stat-label">Medium</span>
          <span className="stat-value stat-value-lg">{mediumCount}</span>
        </div>
        <div className="stat-item stat-card stat-card-verified">
          <span className="stat-label">Low</span>
          <span className="stat-value stat-value-lg">{lowCount}</span>
        </div>
      </div>

      {categories.length > 0 && (
        <Panel title="Filter by Category" className="threat-filters-panel">
          <div className="threat-category-filters">
            <button
              className={`filter-chip ${filter === null ? 'active' : ''}`}
              onClick={() => setFilter(null)}
            >
              All ({threats.length})
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                className={`filter-chip ${filter === cat ? 'active' : ''}`}
                onClick={() => setFilter(filter === cat ? null : cat)}
              >
                {cat}
              </button>
            ))}
          </div>
        </Panel>
      )}

      {sorted.length === 0 ? (
        <Panel title="Findings">
          <div className="empty-state">
            <Icon name="shield" size={32} />
            <p>No threats detected in the captured evidence.</p>
          </div>
        </Panel>
      ) : (
        <div className="threat-cards">
          {sorted.map((t, i) => (
            <Panel
              key={`${t.category}-${i}`}
              className={`threat-card threat-card-${t.severity.toLowerCase()}`}
              actions={<StateMark state={severityToState(t.severity)} label={t.severity} size="sm" />}
            >
              <div className="threat-card-header">
                <span className="threat-card-category">{t.category}</span>
              </div>
              <div className="threat-card-body">
                <div className="threat-card-section">
                  <span className="threat-card-label">Evidence</span>
                  <p className="threat-card-text">{t.evidence}</p>
                </div>
                <div className="threat-card-section">
                  <span className="threat-card-label">Recommendation</span>
                  <p className="threat-card-text threat-card-recommendation">{t.recommendation}</p>
                </div>
              </div>
            </Panel>
          ))}
        </div>
      )}
    </div>
  );
}
