import { useRef, useState } from 'react';
import { Panel, SectionHeading, StateMark, Icon } from '@/components';
import { formatNumber } from '@/evidence';
import type { EvidenceReport } from '@/evidence';
import { runLiveAnalysis, loadEvidenceExport, type LoadResult, type LiveAnalysisResult } from '@/api';

interface WorkspaceProps {
  report: EvidenceReport;
  onReportChange: (report: EvidenceReport) => void;
  source: string;
  onSourceChange: (source: string) => void;
}

export function Workspace({ report, onReportChange, source, onSourceChange }: WorkspaceProps) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [liveLoading, setLiveLoading] = useState(false);
  const [result, setResult] = useState<LoadResult | LiveAnalysisResult | null>(null);

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    const res = await loadEvidenceExport(file);
    setResult(res);
    onReportChange(res.report);
    onSourceChange(res.source);
    setLoading(false);
  }

  async function handleLiveAnalysis(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setLiveLoading(true);
    const res = await runLiveAnalysis(file);
    setResult(res);
    if (!res.error) {
      onReportChange(res.report);
      onSourceChange('live');
    }
    setLiveLoading(false);
  }

  return (
    <div className="screen screen-workspace">
      <SectionHeading
        title="Workspace"
        subtitle="Import evidence files and run live analysis"
        icon="workspace"
      />

      <div className="workspace-grid">
        <Panel title="Import Evidence Export" className="workspace-panel">
          <p className="workspace-desc">
            Load a previously exported evidence JSON file to review captured traffic analysis.
          </p>
          <input
            ref={fileRef}
            type="file"
            accept=".json"
            onChange={handleFile}
            className="file-input"
            disabled={loading}
          />
          {loading && <StateMark state="info" label="Loading..." />}
        </Panel>

        <Panel title="Live Analysis" className="workspace-panel" actions={<Icon name="search" />}>
          <p className="workspace-desc">
            Upload a <code>.pcap</code> or <code>.pcapng</code> capture file to run live analysis
            against the deployed Python backend.
          </p>
          <input
            type="file"
            accept=".pcap,.pcapng,.cap"
            onChange={handleLiveAnalysis}
            className="file-input"
            disabled={liveLoading}
          />
          {liveLoading && <StateMark state="info" label="Analyzing capture..." />}
        </Panel>
      </div>

      {result && (
        <Panel title="Last Result" className="workspace-result">
          {result.error ? (
            <div className="result-error">
              <StateMark state="critical" label="Error" />
              <p>{result.error}</p>
            </div>
          ) : (
            <div className="result-ok">
              <StateMark state="verified" label="Loaded successfully" />
              <p>
                {'source' in result
                  ? `Loaded from ${result.source} source`
                  : 'Live analysis complete'}
              </p>
            </div>
          )}
        </Panel>
      )}

      <Panel title="Current Evidence Overview" className="workspace-overview">
        <div className="stat-grid">
          <div className="stat-item">
            <span className="stat-label">Case</span>
            <span className="stat-value">{report.caseLabel}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Source</span>
            <span className="stat-value">{source}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Events</span>
            <span className="stat-value">{report.events.length}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Sessions</span>
            <span className="stat-value">{report.sessions.length}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Certificates</span>
            <span className="stat-value">{report.certificates.length}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Data Volume</span>
            <span className="stat-value">
              {formatNumber(report.events.reduce((s, e) => s + (e.bytes || 0), 0))}
            </span>
          </div>
        </div>
      </Panel>
    </div>
  );
}
