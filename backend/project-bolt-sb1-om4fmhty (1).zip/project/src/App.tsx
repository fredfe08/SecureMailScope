import { useState, useMemo } from 'react';
import { Icon, StateMark } from '@/components';
import { demoReport } from '@/evidence';
import type { EvidenceReport } from '@/evidence';
import { detectThreats } from '@/lib/fraudDetection';
import type { ThreatFinding } from '@/lib/fraudDetection';
import { Workspace } from '@/screens/Workspace';
import { Investigation } from '@/screens/Investigation';
import { Sessions } from '@/screens/Sessions';
import { Starttls } from '@/screens/Starttls';
import { TlsCertificates } from '@/screens/TlsCertificates';
import { RawEvidence } from '@/screens/RawEvidence';
import { ThreatDetection } from '@/screens/ThreatDetection';
import { AiSummary } from '@/screens/AiSummary';

type Screen =
  | 'workspace'
  | 'investigation'
  | 'sessions'
  | 'starttls'
  | 'tls'
  | 'evidence'
  | 'threats'
  | 'ai-summary';

interface NavItem {
  id: Screen;
  label: string;
  icon: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'workspace', label: 'Workspace', icon: 'workspace' },
  { id: 'investigation', label: 'Investigation', icon: 'investigation' },
  { id: 'sessions', label: 'Sessions', icon: 'sessions' },
  { id: 'starttls', label: 'STARTTLS', icon: 'starttls' },
  { id: 'tls', label: 'TLS & certificates', icon: 'tls' },
  { id: 'evidence', label: 'Raw evidence', icon: 'evidence' },
  { id: 'threats', label: 'Threat Detection', icon: 'threat' },
  { id: 'ai-summary', label: 'AI Summary', icon: 'ai' },
];

function App() {
  const [screen, setScreen] = useState<Screen>('workspace');
  const [report, setReport] = useState<EvidenceReport>(demoReport);
  const [source, setSource] = useState<string>('demo');
  const [aiSummary, setAiSummary] = useState<string | null>(null);

  const threats: ThreatFinding[] = useMemo(() => detectThreats(report), [report]);

  function handleReportChange(newReport: EvidenceReport) {
    setReport(newReport);
    setAiSummary(null);
  }

  function renderScreen() {
    switch (screen) {
      case 'workspace':
        return (
          <Workspace
            report={report}
            onReportChange={handleReportChange}
            source={source}
            onSourceChange={setSource}
          />
        );
      case 'investigation':
        return <Investigation report={report} threats={threats} aiSummary={aiSummary} />;
      case 'sessions':
        return <Sessions report={report} />;
      case 'starttls':
        return <Starttls report={report} />;
      case 'tls':
        return <TlsCertificates report={report} />;
      case 'evidence':
        return <RawEvidence report={report} />;
      case 'threats':
        return <ThreatDetection threats={threats} />;
      case 'ai-summary':
        return <AiSummary report={report} threats={threats} />;
      default:
        return null;
    }
  }

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="sidebar-logo">
            <Icon name="shield" size={24} />
          </div>
          <div className="sidebar-title-group">
            <h1 className="sidebar-title">SecureMailScope</h1>
            <p className="sidebar-subtitle">SIH26159 · NTRO</p>
          </div>
        </div>

        <nav className="sidebar-nav">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${screen === item.id ? 'active' : ''}`}
              onClick={() => setScreen(item.id)}
            >
              <span className="nav-item-icon">
                <Icon name={item.icon} size={18} />
              </span>
              <span className="nav-item-label">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-status">
            <StateMark state={source === 'demo' ? 'info' : 'verified'} label={source} size="sm" />
          </div>
          <p className="sidebar-version">v1.0.0</p>
        </div>
      </aside>

      <main className="main-content">
        {renderScreen()}
      </main>
    </div>
  );
}

export default App;
