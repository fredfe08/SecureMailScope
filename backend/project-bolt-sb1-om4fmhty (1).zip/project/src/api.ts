import { demoReport } from '@/evidence';
import type { EvidenceReport } from '@/evidence';

export interface LoadResult {
  report: EvidenceReport;
  source: 'file' | 'demo';
  error?: string;
}

export async function loadEvidenceExport(file: File): Promise<LoadResult> {
  if (file.name.endsWith('.json')) {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as EvidenceReport;
      if (!parsed.events || !parsed.sessions) {
        return { report: demoReport, source: 'demo', error: 'Invalid evidence file format' };
      }
      return { report: parsed, source: 'file' };
    } catch {
      return { report: demoReport, source: 'demo', error: 'Failed to parse JSON file' };
    }
  }
  return { report: demoReport, source: 'demo' };
}

export interface LiveAnalysisResult {
  report: EvidenceReport;
  error?: string;
}

export async function runLiveAnalysis(file: File): Promise<LiveAnalysisResult> {
  const baseUrl = import.meta.env.VITE_BACKEND_URL as string | undefined;

  if (!baseUrl) {
    return {
      report: demoReport,
      error: 'Backend URL not configured. Set VITE_BACKEND_URL to enable live analysis.',
    };
  }

  try {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(`${baseUrl}/api/analyze`, {
      method: 'POST',
      body: formData,
      mode: 'cors',
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => '');
      return {
        report: demoReport,
        error: `Backend returned ${response.status} ${response.statusText}${errorText ? ': ' + errorText : ''}`,
      };
    }

    const data = (await response.json()) as EvidenceReport;

    if (!data.events || !data.sessions) {
      return {
        report: demoReport,
        error: 'Backend returned an invalid analysis result',
      };
    }

    return { report: data };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      report: demoReport,
      error: `Network error: ${message}. Check that the backend is reachable and CORS is configured.`,
    };
  }
}
