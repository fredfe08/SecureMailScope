export type EvidenceState =
  | 'verified'
  | 'failed'
  | 'warning'
  | 'info'
  | 'suspicious'
  | 'critical'
  | 'unknown';

export interface EvidenceEvent {
  id: string;
  timestamp: string;
  source: string;
  destination: string;
  protocol: 'SMTP' | 'STARTTLS' | 'TLS' | 'DNS' | 'TCP' | 'HTTP' | 'IMAP' | 'POP3';
  state: EvidenceState;
  message: string;
  details?: string;
  bytes?: number;
  port?: number;
  duration?: number;
}

export interface Session {
  id: string;
  startTime: string;
  endTime: string;
  source: string;
  destination: string;
  protocol: string;
  port: number;
  state: EvidenceState;
  eventCount: number;
  bytesTransferred: number;
  events: EvidenceEvent[];
}

export interface TlsCertificate {
  id: string;
  hostname: string;
  issuer: string;
  subject: string;
  validFrom: string;
  validTo: string;
  serialNumber: string;
  signatureAlgorithm: string;
  keyType: string;
  keyLength: number;
  san: string[];
  state: EvidenceState;
  details: string;
}

export interface StarttlsFinding {
  id: string;
  server: string;
  port: number;
  supported: boolean;
  forced: boolean;
  state: EvidenceState;
  details: string;
}

export interface TlsFinding {
  id: string;
  server: string;
  version: string;
  cipher: string;
  keyExchange: string;
  state: EvidenceState;
  details: string;
}

export interface DnsRecord {
  id: string;
  query: string;
  type: string;
  answer: string;
  ttl: number;
  state: EvidenceState;
  details: string;
}

export interface EvidenceReport {
  caseLabel: string;
  caseTitle: string;
  generatedAt: string;
  analyst: string;
  sourceFile: string;
  summary: string;
  events: EvidenceEvent[];
  sessions: Session[];
  certificates: TlsCertificate[];
  starttlsFindings: StarttlsFinding[];
  tlsFindings: TlsFinding[];
  dnsRecords: DnsRecord[];
}

export function fileStem(filename: string): string {
  return filename.replace(/\.[^/.]+$/, '');
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(2) + ' GB';
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(2) + ' MB';
  if (n >= 1_000) return (n / 1_000).toFixed(2) + ' KB';
  return n + ' B';
}

export function selectedEvents(events: EvidenceEvent[], filter?: EvidenceState): EvidenceEvent[] {
  if (!filter) return events;
  return events.filter((e) => e.state === filter);
}

export function smtpConversation(session: Session): EvidenceEvent[] {
  return session.events.filter(
    (e) => e.protocol === 'SMTP' || e.protocol === 'STARTTLS'
  );
}

const now = new Date('2026-09-07T09:00:00Z');

function ts(offset: number): string {
  return new Date(now.getTime() + offset * 1000).toISOString();
}

export const demoReport: EvidenceReport = {
  caseLabel: 'SIH26159',
  caseTitle: 'NTRO — Secure Mail Scope Investigation',
  generatedAt: now.toISOString(),
  analyst: 'Automated Analysis',
  sourceFile: 'capture-sample.pcapng',
  summary:
    'Network capture analysis of SMTP/TLS traffic reveals multiple security concerns including weak TLS configurations, suspicious DNS responses, and potential credential exposure over unencrypted channels.',
  events: [
    { id: 'evt-001', timestamp: ts(0), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'TCP', state: 'info', message: 'TCP connection established', port: 25, bytes: 0 },
    { id: 'evt-002', timestamp: ts(1), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'verified', message: 'EHLO mail.internal.local', port: 25 },
    { id: 'evt-003', timestamp: ts(2), source: '203.0.113.5:25', destination: '10.0.1.42', protocol: 'SMTP', state: 'warning', message: '250-STARTTLS not advertised', port: 25, details: 'Server did not advertise STARTTLS capability' },
    { id: 'evt-004', timestamp: ts(3), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'critical', message: 'AUTH LOGIN sent over plaintext', port: 25, details: 'Credentials transmitted without TLS encryption' },
    { id: 'evt-005', timestamp: ts(5), source: '10.0.1.42', destination: '198.51.100.10:465', protocol: 'SMTP', state: 'verified', message: 'SMTPS connection established', port: 465 },
    { id: 'evt-006', timestamp: ts(6), source: '10.0.1.42', destination: '198.51.100.10:465', protocol: 'TLS', state: 'warning', message: 'TLS 1.0 negotiated', port: 465, details: 'Deprecated TLS version — TLS 1.0 is no longer considered secure' },
    { id: 'evt-007', timestamp: ts(7), source: '10.0.1.42', destination: '198.51.100.10:465', protocol: 'TLS', state: 'warning', message: 'Weak cipher: RSA-AES128-CBC-SHA', port: 465, details: 'CBC mode cipher susceptible to padding oracle attacks' },
    { id: 'evt-008', timestamp: ts(10), source: '10.0.1.42', destination: '8.8.8.8:53', protocol: 'DNS', state: 'info', message: 'A query for mail.paypa1.com', port: 53 },
    { id: 'evt-009', timestamp: ts(11), source: '8.8.8.8:53', destination: '10.0.1.42', protocol: 'DNS', state: 'suspicious', message: 'A response: 192.168.99.50', port: 53, details: 'Lookalike domain — paypa1.com (with digit 1) mimics paypal.com' },
    { id: 'evt-010', timestamp: ts(15), source: '10.0.1.42', destination: '192.168.99.50:443', protocol: 'TLS', state: 'suspicious', message: 'TLS handshake to lookalike host', port: 443, details: 'Certificate CN mismatch — CN: paypa1.com, not paypal.com' },
    { id: 'evt-011', timestamp: ts(20), source: '10.0.1.42', destination: '45.33.32.156:443', protocol: 'TLS', state: 'critical', message: 'Self-signed certificate detected', port: 443, details: 'Issuer = Subject, no trusted CA in chain' },
    { id: 'evt-012', timestamp: ts(25), source: '10.0.1.42', destination: '45.33.32.156:443', protocol: 'TLS', state: 'warning', message: 'Certificate expired', port: 443, details: 'NotAfter: 2026-01-15 — certificate is 8 months past expiry' },
    { id: 'evt-013', timestamp: ts(30), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'info', message: 'MAIL FROM: sender@internal.local', port: 25 },
    { id: 'evt-014', timestamp: ts(31), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'info', message: 'RCPT TO: target@external.com', port: 25 },
    { id: 'evt-015', timestamp: ts(35), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'info', message: 'DATA transfer', port: 25, bytes: 524288, details: '512 KB message body' },
    { id: 'evt-016', timestamp: ts(40), source: '10.0.1.42', destination: '198.51.100.10:465', protocol: 'SMTP', state: 'verified', message: 'AUTH PLAIN over TLS', port: 465, details: 'Credentials encrypted via SMTPS' },
    { id: 'evt-017', timestamp: ts(45), source: '10.0.1.42', destination: '198.51.100.10:465', protocol: 'SMTP', state: 'info', message: 'DATA transfer', port: 465, bytes: 10485760, details: '10 MB message body' },
    { id: 'evt-018', timestamp: ts(50), source: '10.0.1.42', destination: '8.8.8.8:53', protocol: 'DNS', state: 'info', message: 'MX query for legitbank.com', port: 53 },
    { id: 'evt-019', timestamp: ts(51), source: '8.8.8.8:53', destination: '10.0.1.42', protocol: 'DNS', state: 'suspicious', message: 'MX response: mail.1egitbank.com', port: 53, details: 'Lookalike domain — 1egitbank.com (digit 1) mimics legitbank.com' },
    { id: 'evt-020', timestamp: ts(55), source: '10.0.1.42', destination: '185.220.101.5:443', protocol: 'TLS', state: 'critical', message: 'Connection to known TOR exit node', port: 443, details: '185.220.101.5 listed on Tor exit relay blacklist' },
    { id: 'evt-021', timestamp: ts(60), source: '10.0.1.42', destination: '185.220.101.5:443', protocol: 'TLS', state: 'critical', message: 'Repeated beaconing detected', port: 443, details: '7 connections in 120s at regular 15s intervals' },
    { id: 'evt-022', timestamp: ts(75), source: '10.0.1.42', destination: '185.220.101.5:443', protocol: 'TLS', state: 'critical', message: 'Beaconing continues', port: 443, details: 'Periodic connection #3 — C2 pattern' },
    { id: 'evt-023', timestamp: ts(90), source: '10.0.1.42', destination: '185.220.101.5:443', protocol: 'TLS', state: 'critical', message: 'Beaconing continues', port: 443, details: 'Periodic connection #4 — C2 pattern' },
    { id: 'evt-024', timestamp: ts(105), source: '10.0.1.42', destination: '185.220.101.5:443', protocol: 'TLS', state: 'critical', message: 'Beaconing continues', port: 443, details: 'Periodic connection #5 — C2 pattern' },
    { id: 'evt-025', timestamp: ts(120), source: '10.0.1.42', destination: '185.220.101.5:443', protocol: 'TLS', state: 'critical', message: 'Beaconing continues', port: 443, details: 'Periodic connection #6 — C2 pattern' },
    { id: 'evt-026', timestamp: ts(135), source: '10.0.1.42', destination: '185.220.101.5:443', protocol: 'TLS', state: 'critical', message: 'Beaconing continues', port: 443, details: 'Periodic connection #7 — C2 pattern' },
    { id: 'evt-027', timestamp: ts(140), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'warning', message: 'AUTH LOGIN failed (attempt 1)', port: 25, details: '535 Authentication failed' },
    { id: 'evt-028', timestamp: ts(142), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'warning', message: 'AUTH LOGIN failed (attempt 2)', port: 25, details: '535 Authentication failed' },
    { id: 'evt-029', timestamp: ts(144), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'warning', message: 'AUTH LOGIN failed (attempt 3)', port: 25, details: '535 Authentication failed' },
    { id: 'evt-030', timestamp: ts(146), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'warning', message: 'AUTH LOGIN failed (attempt 4)', port: 25, details: '535 Authentication failed' },
    { id: 'evt-031', timestamp: ts(148), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'warning', message: 'AUTH LOGIN failed (attempt 5)', port: 25, details: '535 Authentication failed' },
    { id: 'evt-032', timestamp: ts(150), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'warning', message: 'AUTH LOGIN failed (attempt 6)', port: 25, details: '535 Authentication failed' },
    { id: 'evt-033', timestamp: ts(152), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'warning', message: 'AUTH LOGIN failed (attempt 7)', port: 25, details: '535 Authentication failed' },
    { id: 'evt-034', timestamp: ts(154), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'warning', message: 'AUTH LOGIN failed (attempt 8)', port: 25, details: '535 Authentication failed' },
    { id: 'evt-035', timestamp: ts(160), source: '10.0.1.42', destination: '192.168.99.50:443', protocol: 'TLS', state: 'critical', message: 'Large data transfer to lookalike host', port: 443, bytes: 52428800, details: '50 MB transferred to paypa1.com lookalike' },
    { id: 'evt-036', timestamp: ts(165), source: '10.0.1.42', destination: '203.0.113.5:25', protocol: 'SMTP', state: 'info', message: 'QUIT', port: 25 },
    { id: 'evt-037', timestamp: ts(170), source: '10.0.1.42', destination: '203.0.113.5:22', protocol: 'TCP', state: 'info', message: 'TCP SYN to port 22', port: 22 },
    { id: 'evt-038', timestamp: ts(171), source: '10.0.1.42', destination: '203.0.113.5:23', protocol: 'TCP', state: 'info', message: 'TCP SYN to port 23', port: 23 },
    { id: 'evt-039', timestamp: ts(172), source: '10.0.1.42', destination: '203.0.113.5:21', protocol: 'TCP', state: 'info', message: 'TCP SYN to port 21', port: 21 },
    { id: 'evt-040', timestamp: ts(173), source: '10.0.1.42', destination: '203.0.113.5:3389', protocol: 'TCP', state: 'suspicious', message: 'TCP SYN to port 3389', port: 3389, details: 'RDP port probe' },
    { id: 'evt-041', timestamp: ts(174), source: '10.0.1.42', destination: '203.0.113.5:1433', protocol: 'TCP', state: 'suspicious', message: 'TCP SYN to port 1433', port: 1433, details: 'SQL Server port probe' },
    { id: 'evt-042', timestamp: ts(175), source: '10.0.1.42', destination: '203.0.113.5:3306', protocol: 'TCP', state: 'suspicious', message: 'TCP SYN to port 3306', port: 3306, details: 'MySQL port probe' },
    { id: 'evt-043', timestamp: ts(176), source: '10.0.1.42', destination: '203.0.113.5:5432', protocol: 'TCP', state: 'suspicious', message: 'TCP SYN to port 5432', port: 5432, details: 'PostgreSQL port probe' },
    { id: 'evt-044', timestamp: ts(177), source: '10.0.1.42', destination: '203.0.113.5:6379', protocol: 'TCP', state: 'suspicious', message: 'TCP SYN to port 6379', port: 6379, details: 'Redis port probe' },
    { id: 'evt-045', timestamp: ts(178), source: '10.0.1.42', destination: '203.0.113.5:27017', protocol: 'TCP', state: 'suspicious', message: 'TCP SYN to port 27017', port: 27017, details: 'MongoDB port probe' },
    { id: 'evt-046', timestamp: ts(180), source: '10.0.1.42', destination: '198.51.100.10:465', protocol: 'TLS', state: 'warning', message: 'TLS handshake with RSA key exchange', port: 465, details: 'No forward secrecy — RSA key exchange does not provide PFS' },
    { id: 'evt-047', timestamp: ts(185), source: '10.0.1.42', destination: '198.51.100.10:465', protocol: 'TLS', state: 'critical', message: 'Malformed TLS handshake', port: 465, details: 'Unexpected message type in ServerHello — possible TLS downgrade attack' },
    { id: 'evt-048', timestamp: ts(190), source: '10.0.1.42', destination: '8.8.8.8:53', protocol: 'DNS', state: 'suspicious', message: 'A query for bank-secure-login.com', port: 53 },
    { id: 'evt-049', timestamp: ts(191), source: '8.8.8.8:53', destination: '10.0.1.42', protocol: 'DNS', state: 'suspicious', message: 'A response: 192.168.99.50', port: 53, details: 'Same IP as paypa1.com — single host serving multiple phishing domains' },
    { id: 'evt-050', timestamp: ts(195), source: '10.0.1.42', destination: '192.168.99.50:443', protocol: 'TLS', state: 'critical', message: 'Certificate hostname mismatch', port: 443, details: 'Requested bank-secure-login.com but certificate CN = paypa1.com' },
  ],
  sessions: [
    {
      id: 'ses-001',
      startTime: ts(0),
      endTime: ts(36),
      source: '10.0.1.42',
      destination: '203.0.113.5:25',
      protocol: 'SMTP',
      port: 25,
      state: 'critical',
      eventCount: 10,
      bytesTransferred: 524288,
      events: [],
    },
    {
      id: 'ses-002',
      startTime: ts(5),
      endTime: ts(180),
      source: '10.0.1.42',
      destination: '198.51.100.10:465',
      protocol: 'SMTPS',
      port: 465,
      state: 'warning',
      eventCount: 8,
      bytesTransferred: 10485760,
      events: [],
    },
    {
      id: 'ses-003',
      startTime: ts(15),
      endTime: ts(160),
      source: '10.0.1.42',
      destination: '192.168.99.50:443',
      protocol: 'HTTPS',
      port: 443,
      state: 'critical',
      eventCount: 4,
      bytesTransferred: 52428800,
      events: [],
    },
    {
      id: 'ses-004',
      startTime: ts(20),
      endTime: ts(135),
      source: '10.0.1.42',
      destination: '185.220.101.5:443',
      protocol: 'HTTPS',
      port: 443,
      state: 'critical',
      eventCount: 7,
      bytesTransferred: 0,
      events: [],
    },
    {
      id: 'ses-005',
      startTime: ts(140),
      endTime: ts(154),
      source: '10.0.1.42',
      destination: '203.0.113.5:25',
      protocol: 'SMTP',
      port: 25,
      state: 'warning',
      eventCount: 8,
      bytesTransferred: 0,
      events: [],
    },
    {
      id: 'ses-006',
      startTime: ts(170),
      endTime: ts(178),
      source: '10.0.1.42',
      destination: '203.0.113.5',
      protocol: 'TCP',
      port: 0,
      state: 'suspicious',
      eventCount: 8,
      bytesTransferred: 0,
      events: [],
    },
  ],
  certificates: [
    {
      id: 'cert-001',
      hostname: 'mail.legitbank.com',
      issuer: 'DigiCert TLS RSA SHA256 2020 CA1',
      subject: 'mail.legitbank.com',
      validFrom: '2025-06-01',
      validTo: '2027-06-01',
      serialNumber: '0A:1B:2C:3D:4E:5F',
      signatureAlgorithm: 'SHA-256',
      keyType: 'RSA',
      keyLength: 2048,
      san: ['mail.legitbank.com', 'legitbank.com'],
      state: 'verified',
      details: 'Valid certificate from trusted CA',
    },
    {
      id: 'cert-002',
      hostname: 'paypa1.com',
      issuer: 'paypa1.com',
      subject: 'paypa1.com',
      validFrom: '2026-08-01',
      validTo: '2027-08-01',
      serialNumber: 'FF:EE:DD:CC:BB:AA',
      signatureAlgorithm: 'SHA-1',
      keyType: 'RSA',
      keyLength: 1024,
      san: ['paypa1.com'],
      state: 'critical',
      details: 'Self-signed certificate with weak key (1024-bit RSA) and deprecated SHA-1 signature',
    },
    {
      id: 'cert-003',
      hostname: '45.33.32.156',
      issuer: '45.33.32.156',
      subject: '45.33.32.156',
      validFrom: '2025-01-15',
      validTo: '2026-01-15',
      serialNumber: '11:22:33:44:55:66',
      signatureAlgorithm: 'SHA-256',
      keyType: 'RSA',
      keyLength: 2048,
      san: [],
      state: 'critical',
      details: 'Self-signed and expired certificate — expired 8 months ago',
    },
    {
      id: 'cert-004',
      hostname: 'bank-secure-login.com',
      issuer: 'paypa1.com',
      subject: 'paypa1.com',
      validFrom: '2026-08-01',
      validTo: '2027-08-01',
      serialNumber: 'FF:EE:DD:CC:BB:AA',
      signatureAlgorithm: 'SHA-1',
      keyType: 'RSA',
      keyLength: 1024,
      san: ['paypa1.com'],
      state: 'critical',
      details: 'Hostname mismatch — certificate CN does not match requested hostname',
    },
  ],
  starttlsFindings: [
    { id: 'st-001', server: '203.0.113.5', port: 25, supported: false, forced: false, state: 'critical', details: 'STARTTLS not advertised — all SMTP traffic on port 25 is unencrypted' },
    { id: 'st-002', server: '198.51.100.10', port: 465, supported: true, forced: true, state: 'verified', details: 'SMTPS (implicit TLS on port 465) — STARTTLS not needed' },
    { id: 'st-003', server: '192.168.99.50', port: 25, supported: false, forced: false, state: 'critical', details: 'STARTTLS not advertised on phishing host' },
    { id: 'st-004', server: '45.33.32.156', port: 25, supported: false, forced: false, state: 'warning', details: 'STARTTLS not advertised — host uses port 443 only' },
  ],
  tlsFindings: [
    { id: 'tls-001', server: '198.51.100.10:465', version: 'TLS 1.0', cipher: 'RSA-AES128-CBC-SHA', keyExchange: 'RSA', state: 'warning', details: 'Deprecated TLS 1.0 with CBC cipher and no forward secrecy' },
    { id: 'tls-002', server: '192.168.99.50:443', version: 'TLS 1.2', cipher: 'ECDHE-RSA-AES256-GCM-SHA384', keyExchange: 'ECDHE', state: 'warning', details: 'Acceptable cipher but certificate is self-signed with weak key' },
    { id: 'tls-003', server: '45.33.32.156:443', version: 'TLS 1.1', cipher: 'RSA-AES256-SHA', keyExchange: 'RSA', state: 'critical', details: 'Deprecated TLS 1.1 with no forward secrecy and expired certificate' },
    { id: 'tls-004', server: '185.220.101.5:443', version: 'TLS 1.2', cipher: 'ECDHE-RSA-AES128-GCM-SHA256', keyExchange: 'ECDHE', state: 'critical', details: 'Strong cipher but host is a known TOR exit node with C2 beaconing pattern' },
    { id: 'tls-005', server: '198.51.100.10:465', version: 'TLS 1.0', cipher: 'Malformed ServerHello', keyExchange: 'RSA', state: 'critical', details: 'Malformed TLS handshake — possible downgrade attack' },
  ],
  dnsRecords: [
    { id: 'dns-001', query: 'mail.paypa1.com', type: 'A', answer: '192.168.99.50', ttl: 300, state: 'suspicious', details: 'Lookalike domain — paypa1.com (digit 1) mimics paypal.com' },
    { id: 'dns-002', query: 'legitbank.com', type: 'MX', answer: 'mail.1egitbank.com', ttl: 3600, state: 'suspicious', details: 'Lookalike MX — 1egitbank.com (digit 1) mimics legitbank.com' },
    { id: 'dns-003', query: 'bank-secure-login.com', type: 'A', answer: '192.168.99.50', ttl: 300, state: 'suspicious', details: 'Same IP as paypa1.com — single host serving multiple phishing domains' },
    { id: 'dns-004', query: 'mail.legitbank.com', type: 'A', answer: '203.0.113.5', ttl: 3600, state: 'verified', details: 'Legitimate mail server address' },
    { id: 'dns-005', query: 'mail.legitbank.com', type: 'MX', answer: 'mail.legitbank.com', ttl: 3600, state: 'verified', details: 'Legitimate MX record' },
  ],
};

export const demoSessions: Session[] = demoReport.sessions;
