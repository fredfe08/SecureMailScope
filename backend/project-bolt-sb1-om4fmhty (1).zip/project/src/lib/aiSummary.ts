import type { EvidenceReport } from '@/evidence';
import type { ThreatFinding } from '@/lib/fraudDetection';

export async function getAISummary(
  evidence: EvidenceReport,
  threats: ThreatFinding[]
): Promise<string> {
  const baseUrl = import.meta.env.VITE_BACKEND_URL as string | undefined;
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

  const endpoint = baseUrl
    ? `${baseUrl}/api/ai-summary`
    : supabaseUrl && supabaseAnonKey
      ? `${supabaseUrl}/functions/v1/ai-summary`
      : null;

  if (!endpoint) {
    return generateLocalSummary(evidence, threats);
  }

  try {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (supabaseUrl && supabaseAnonKey && endpoint.includes(supabaseUrl)) {
      headers['Authorization'] = `Bearer ${supabaseAnonKey}`;
      headers['apikey'] = supabaseAnonKey;
    }

    const response = await fetch(endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        caseLabel: evidence.caseLabel,
        summary: evidence.summary,
        eventCount: evidence.events.length,
        sessionCount: evidence.sessions.length,
        threats: threats.map((t) => ({
          category: t.category,
          severity: t.severity,
          evidence: t.evidence,
        })),
        tlsFindings: evidence.tlsFindings,
        starttlsFindings: evidence.starttlsFindings,
        dnsRecords: evidence.dnsRecords,
        certificates: evidence.certificates,
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    if (typeof data.summary === 'string' && data.summary.length > 0) {
      return data.summary;
    }
    return generateLocalSummary(evidence, threats);
  } catch {
    return generateLocalSummary(evidence, threats);
  }
}

function generateLocalSummary(evidence: EvidenceReport, threats: ThreatFinding[]): string {
  const critical = threats.filter((t) => t.severity === 'Critical');
  const high = threats.filter((t) => t.severity === 'High');
  const medium = threats.filter((t) => t.severity === 'Medium');

  const lines: string[] = [];

  lines.push(
    `Case ${evidence.caseLabel} analysis identified ${evidence.events.length} network events across ${evidence.sessions.length} sessions.`
  );
  lines.push('');

  if (threats.length === 0) {
    lines.push('No significant security threats were detected in the captured traffic. The mail and TLS configurations appear to be operating within expected security parameters.');
    return lines.join('\n');
  }

  lines.push(
    `The investigation surfaced ${threats.length} security finding(s): ${critical.length} critical, ${high.length} high, and ${medium.length} medium severity.`
  );
  lines.push('');

  if (critical.length > 0) {
    lines.push('CRITICAL FINDINGS:');
    for (const t of critical) {
      lines.push(`• ${t.category}: ${t.evidence}`);
    }
    lines.push('');
  }

  if (high.length > 0) {
    lines.push('HIGH SEVERITY FINDINGS:');
    for (const t of high) {
      lines.push(`• ${t.category}: ${t.evidence}`);
    }
    lines.push('');
  }

  if (medium.length > 0) {
    lines.push('MEDIUM SEVERITY FINDINGS:');
    for (const t of medium) {
      lines.push(`• ${t.category}: ${t.evidence}`);
    }
    lines.push('');
  }

  lines.push('SUMMARY ASSESSMENT:');
  if (critical.length > 0) {
    lines.push(
      'This capture shows evidence of active compromise with multiple critical-severity threats. Immediate incident response is recommended: isolate affected hosts, rotate exposed credentials, and block identified malicious infrastructure.'
    );
  } else if (high.length > 0) {
    lines.push(
      'This capture reveals significant security weaknesses that should be remediated promptly. While no active compromise is confirmed, the configuration issues create substantial risk of future attack.'
    );
  } else {
    lines.push(
      'This capture shows minor security weaknesses. Remediation of medium-severity findings will improve the overall security posture.'
    );
  }

  return lines.join('\n');
}
