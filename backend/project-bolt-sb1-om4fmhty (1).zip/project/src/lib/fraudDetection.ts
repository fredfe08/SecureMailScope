import type { EvidenceReport, EvidenceState, EvidenceEvent } from '@/evidence';

export interface ThreatFinding {
  category: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  evidence: string;
  recommendation: string;
}

const LOOKALIKE_PATTERNS = [
  { pattern: /paypa[1l]/i, real: 'paypal.com' },
  { pattern: /1egit/i, real: 'legit' },
  { pattern: /bank-secure-login/i, real: 'legitimate bank domain' },
  { pattern: /amaz[0o]n/i, real: 'amazon.com' },
  { pattern: /g00gle/i, real: 'google.com' },
  { pattern: /micros[0o]ft/i, real: 'microsoft.com' },
];

const SUSPICIOUS_IPS = [
  '185.220.101.5',
  '192.168.99.50',
];

const COMMON_SCAN_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 1433, 3306, 5432, 6379, 8080, 8443, 9200, 27017];

export function detectThreats(report: EvidenceReport): ThreatFinding[] {
  const findings: ThreatFinding[] = [];

  detectPhishing(report, findings);
  detectCredentialTheft(report, findings);
  detectMitm(report, findings);
  detectDnsSpoofing(report, findings);
  detectDataExfiltration(report, findings);
  detectMalwareCommunication(report, findings);
  detectC2Beaconing(report, findings);
  detectPortScanning(report, findings);
  detectBruteForce(report, findings);
  detectTlsAbuse(report, findings);

  return findings;
}

function detectPhishing(report: EvidenceReport, findings: ThreatFinding[]): void {
  const lookalikeDomains = new Set<string>();
  const phishingIps = new Set<string>();

  for (const dns of report.dnsRecords) {
    for (const { pattern, real } of LOOKALIKE_PATTERNS) {
      if (pattern.test(dns.query)) {
        lookalikeDomains.add(dns.query);
        phishingIps.add(dns.answer);
      }
    }
  }

  for (const ev of report.events) {
    for (const { pattern, real } of LOOKALIKE_PATTERNS) {
      if (pattern.test(ev.message) || (ev.details && pattern.test(ev.details))) {
        lookalikeDomains.add(ev.message);
      }
    }
  }

  if (lookalikeDomains.size > 0) {
    findings.push({
      category: 'Phishing',
      severity: 'Critical',
      evidence: `Lookalike domains detected: ${Array.from(lookalikeDomains).join(', ')}. These domains mimic legitimate services using character substitution (e.g., digit "1" for letter "l").`,
      recommendation: 'Block these domains at the DNS resolver and email gateway. Alert users who may have received phishing emails. Submit takedown requests to registrars.',
    });
  }

  if (phishingIps.size > 0) {
    findings.push({
      category: 'Phishing',
      severity: 'High',
      evidence: `Multiple phishing domains resolve to the same IP address(es): ${Array.from(phishingIps).join(', ')}, indicating a shared phishing infrastructure.`,
      recommendation: 'Block these IP addresses at the firewall. Report the hosting provider to abuse channels.',
    });
  }
}

function detectCredentialTheft(report: EvidenceReport, findings: ThreatFinding[]): void {
  const plaintextAuth = report.events.filter(
    (e) =>
      (e.message.includes('AUTH') || e.message.includes('LOGIN') || e.message.includes('PLAIN')) &&
      (e.protocol === 'SMTP' || e.protocol === 'IMAP' || e.protocol === 'POP3') &&
      e.state === 'critical'
  );

  if (plaintextAuth.length > 0) {
    findings.push({
      category: 'Credential Theft',
      severity: 'Critical',
      evidence: `${plaintextAuth.length} authentication event(s) detected over unencrypted channels. Credentials were transmitted in plaintext on port ${plaintextAuth[0].port}.`,
      recommendation: 'Immediately rotate all credentials that may have been exposed. Enforce STARTTLS or SMTPS on all mail servers. Audit authentication logs for unauthorized access.',
    });
  }
}

function detectMitm(report: EvidenceReport, findings: ThreatFinding[]): void {
  const selfSigned = report.certificates.filter(
    (c) => c.issuer === c.subject && c.state === 'critical'
  );

  if (selfSigned.length > 0) {
    findings.push({
      category: 'Man-in-the-Middle (MITM)',
      severity: 'Critical',
      evidence: `Self-signed certificate(s) detected for: ${selfSigned.map((c) => c.hostname).join(', ')}. Issuer equals subject, indicating no trusted CA validation. Possible MITM interception.`,
      recommendation: 'Investigate whether these certificates are expected. If not, inspect the network path for interception devices. Pin certificates for critical services.',
    });
  }

  const mismatched = report.certificates.filter(
    (c) => c.details.includes('mismatch') || c.details.includes('CN does not match')
  );

  if (mismatched.length > 0) {
    findings.push({
      category: 'Man-in-the-Middle (MITM)',
      severity: 'High',
      evidence: `Certificate hostname mismatch detected for: ${mismatched.map((c) => c.hostname).join(', ')}. The server presented a certificate for a different domain.`,
      recommendation: 'Verify the intended destination. Block connections to hosts with mismatched certificates. Check for DNS poisoning or local proxy interception.',
    });
  }

  const malformed = report.events.filter(
    (e) => e.message.toLowerCase().includes('malformed') || (e.details || '').toLowerCase().includes('downgrade')
  );

  if (malformed.length > 0) {
    findings.push({
      category: 'Man-in-the-Middle (MITM)',
      severity: 'Critical',
      evidence: `Malformed TLS handshake detected — possible downgrade attack. ${malformed.map((e) => e.details || e.message).join('; ')}`,
      recommendation: 'Investigate the network path for TLS stripping proxies. Enforce minimum TLS version (1.2+) and enable HSTS on all services.',
    });
  }
}

function detectDnsSpoofing(report: EvidenceReport, findings: ThreatFinding[]): void {
  const suspiciousDns = report.dnsRecords.filter((d) => d.state === 'suspicious');

  if (suspiciousDns.length > 0) {
    const sharedIps: Record<string, string[]> = {};
    for (const d of suspiciousDns) {
      if (!sharedIps[d.answer]) sharedIps[d.answer] = [];
      sharedIps[d.answer].push(d.query);
    }

    const sharedEntries = Object.entries(sharedIps).filter(([, domains]) => domains.length > 1);

    if (sharedEntries.length > 0) {
      findings.push({
        category: 'DNS Spoofing',
        severity: 'High',
        evidence: `Multiple unrelated domains resolve to the same IP: ${sharedEntries.map(([ip, domains]) => `${ip} (${domains.join(', ')})`).join('; ')}. This pattern is consistent with DNS spoofing or a shared phishing infrastructure.`,
        recommendation: 'Verify DNS responses against a trusted resolver. Flush DNS caches. Monitor for further spoofed responses from the same resolver.',
      });
    } else {
      findings.push({
        category: 'DNS Spoofing',
        severity: 'Medium',
        evidence: `Suspicious DNS responses detected: ${suspiciousDns.map((d) => `${d.query} → ${d.answer}`).join(', ')}`,
        recommendation: 'Cross-verify these DNS responses with an alternative resolver. Investigate the resolver for compromise.',
      });
    }
  }
}

function detectDataExfiltration(report: EvidenceReport, findings: ThreatFinding[]): void {
  const largeTransfers = report.events.filter((e) => (e.bytes || 0) > 10_000_000);

  if (largeTransfers.length > 0) {
    const suspiciousTransfers = largeTransfers.filter(
      (e) => SUSPICIOUS_IPS.includes(e.destination.split(':')[0]) || e.state === 'critical'
    );

    if (suspiciousTransfers.length > 0) {
      findings.push({
        category: 'Data Exfiltration',
        severity: 'Critical',
        evidence: `Large data transfer(s) to suspicious destinations: ${suspiciousTransfers.map((e) => `${(e.bytes! / 1_000_000).toFixed(1)} MB to ${e.destination}`).join(', ')}`,
        recommendation: 'Immediately investigate the source host and user. Quarantine the destination if external. Review DLP logs for classified data.',
      });
    } else if (largeTransfers.length > 0) {
      findings.push({
        category: 'Data Exfiltration',
        severity: 'Medium',
        evidence: `Large outbound data transfer(s) detected: ${largeTransfers.map((e) => `${(e.bytes! / 1_000_000).toFixed(1)} MB to ${e.destination}`).join(', ')}`,
        recommendation: 'Review whether these transfers are expected business activity. Monitor for unusual patterns.',
      });
    }
  }
}

function detectMalwareCommunication(report: EvidenceReport, findings: ThreatFinding[]): void {
  const suspiciousConnections = report.events.filter(
    (e) => SUSPICIOUS_IPS.includes(e.destination.split(':')[0]) && e.state === 'critical'
  );

  const torConnections = report.events.filter(
    (e) => (e.details || '').toLowerCase().includes('tor')
  );

  if (torConnections.length > 0) {
    findings.push({
      category: 'Malware Communication',
      severity: 'Critical',
      evidence: `${torConnections.length} connection(s) to known TOR exit node(s): ${torConnections[0].destination}. TOR is commonly used for malware C2 and data exfiltration.`,
      recommendation: 'Block TOR exit node IP ranges at the firewall. Investigate the source host for malware infection. Run a full endpoint security scan.',
    });
  }

  if (suspiciousConnections.length > 0) {
    findings.push({
      category: 'Malware Communication',
      severity: 'High',
      evidence: `Repeated connections to suspicious IP addresses: ${Array.from(new Set(suspiciousConnections.map((e) => e.destination.split(':')[0]))).join(', ')}`,
      recommendation: 'Investigate the source host for compromise. Check threat intelligence feeds for these IPs. Block at the perimeter if confirmed malicious.',
    });
  }
}

function detectC2Beaconing(report: EvidenceReport, findings: ThreatFinding[]): void {
  const beaconingEvents = report.events.filter(
    (e) => (e.details || '').toLowerCase().includes('beacon') || (e.details || '').toLowerCase().includes('c2')
  );

  if (beaconingEvents.length >= 3) {
    const dest = beaconingEvents[0].destination;
    const timestamps = beaconingEvents.map((e) => new Date(e.timestamp).getTime());
    const intervals: number[] = [];
    for (let i = 1; i < timestamps.length; i++) {
      intervals.push(timestamps[i] - timestamps[i - 1]);
    }
    const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    const variance = intervals.reduce((s, i) => s + Math.pow(i - avgInterval, 2), 0) / intervals.length;
    const regular = Math.sqrt(variance) < avgInterval * 0.3;

    findings.push({
      category: 'Command & Control (C2)',
      severity: 'Critical',
      evidence: `Periodic beaconing detected to ${dest}: ${beaconingEvents.length} connections at ~${(avgInterval / 1000).toFixed(0)}s intervals${regular ? ' with highly regular timing' : ''}. This pattern is consistent with C2 callback behavior.`,
      recommendation: 'Isolate the source host immediately. Capture memory for forensic analysis. Block the C2 server at the firewall. Investigate for installed malware or implants.',
    });
  }
}

function detectPortScanning(report: EvidenceReport, findings: ThreatFinding[]): void {
  const synEvents = report.events.filter(
    (e) => e.protocol === 'TCP' && e.message.includes('SYN')
  );

  if (synEvents.length >= 5) {
    const byDest: Record<string, number[]> = {};
    for (const e of synEvents) {
      const ip = e.destination.split(':')[0];
      if (!byDest[ip]) byDest[ip] = [];
      if (e.port) byDest[ip].push(e.port);
    }

    const scanTargets = Object.entries(byDest).filter(([, ports]) => ports.length >= 5);

    if (scanTargets.length > 0) {
      findings.push({
        category: 'Port Scanning',
        severity: 'High',
        evidence: `Port scanning detected against ${scanTargets.map(([ip, ports]) => `${ip} (${ports.length} ports: ${ports.join(', ')})`).join('; ')}. Multiple ports probed in rapid succession.`,
        recommendation: 'Block the scanning source at the firewall. Verify that scanned services are not exposed unnecessarily. Enable port scan detection on the IDS/IPS.',
      });
    }
  }

  const scanPortEvents = report.events.filter(
    (e) => (e.details || '').toLowerCase().includes('probe') || (e.details || '').toLowerCase().includes('scan')
  );

  if (scanPortEvents.length >= 3 && synEvents.length < 5) {
    findings.push({
      category: 'Port Scanning',
      severity: 'Medium',
      evidence: `Suspicious port probing detected: ${scanPortEvents.length} probes to common service ports including ${Array.from(new Set(scanPortEvents.map((e) => e.port).filter(Boolean))).join(', ')}.`,
      recommendation: 'Monitor for escalation. Verify firewall rules restrict access to only required ports.',
    });
  }
}

function detectBruteForce(report: EvidenceReport, findings: ThreatFinding[]): void {
  const failedAuths = report.events.filter(
    (e) => e.message.toLowerCase().includes('failed') || (e.details || '').toLowerCase().includes('authentication failed')
  );

  if (failedAuths.length >= 5) {
    const byDest: Record<string, EvidenceEvent[]> = {};
    for (const e of failedAuths) {
      const key = e.destination;
      if (!byDest[key]) byDest[key] = [];
      byDest[key].push(e);
    }

    const bruteTargets = Object.entries(byDest).filter(([, events]) => events.length >= 5);

    if (bruteTargets.length > 0) {
      findings.push({
        category: 'Brute-Force Attempts',
        severity: 'High',
        evidence: `${failedAuths.length} failed authentication attempts detected against ${bruteTargets.map(([dest, events]) => `${dest} (${events.length} attempts)`).join(', ')}. This volume indicates a brute-force attack.`,
        recommendation: 'Enable account lockout policies. Implement rate limiting on authentication. Review whether any attempts succeeded. Block the source IP if external.',
      });
    }
  }
}

function detectTlsAbuse(report: EvidenceReport, findings: ThreatFinding[]): void {
  const weakTls = report.tlsFindings.filter(
    (f) => f.version === 'TLS 1.0' || f.version === 'TLS 1.1'
  );

  if (weakTls.length > 0) {
    findings.push({
      category: 'Protocol/TLS Abuse',
      severity: 'High',
      evidence: `Deprecated TLS version(s) in use: ${weakTls.map((f) => `${f.version} on ${f.server}`).join(', ')}. These versions have known vulnerabilities including BEAST and POODLE attacks.`,
      recommendation: 'Disable TLS 1.0 and 1.1 on all servers. Require TLS 1.2 or higher. Update client software that depends on legacy TLS.',
    });
  }

  const weakCiphers = report.tlsFindings.filter(
    (f) => f.cipher.includes('CBC') || f.cipher.includes('RSA-AES') || f.keyExchange === 'RSA'
  );

  if (weakCiphers.length > 0) {
    findings.push({
      category: 'Protocol/TLS Abuse',
      severity: 'Medium',
      evidence: `Weak cipher suites detected: ${weakCiphers.map((f) => `${f.cipher} (${f.server})`).join(', ')}. CBC mode ciphers are vulnerable to padding oracle attacks; RSA key exchange lacks forward secrecy.`,
      recommendation: 'Reconfigure TLS to prefer AEAD ciphers (GCM/ChaCha20-Poly1305) with ECDHE key exchange. Remove CBC and RSA-only suites from the allowed list.',
    });
  }

  const weakCerts = report.certificates.filter(
    (c) => c.keyLength < 2048 || c.signatureAlgorithm === 'SHA-1'
  );

  if (weakCerts.length > 0) {
    findings.push({
      category: 'Protocol/TLS Abuse',
      severity: 'Medium',
      evidence: `Weak certificate(s) detected: ${weakCerts.map((c) => `${c.hostname} (${c.keyLength}-bit ${c.keyType}, ${c.signatureAlgorithm})`).join(', ')}. Keys below 2048 bits and SHA-1 signatures are no longer considered secure.`,
      recommendation: 'Reissue certificates with minimum 2048-bit RSA or 256-bit EC keys and SHA-256 signatures. Revoke the weak certificates.',
    });
  }

  const malformedHandshakes = report.events.filter(
    (e) => e.message.toLowerCase().includes('malformed') || (e.details || '').toLowerCase().includes('downgrade')
  );

  if (malformedHandshakes.length > 0) {
    findings.push({
      category: 'Protocol/TLS Abuse',
      severity: 'Critical',
      evidence: `Malformed TLS handshake(s) detected: ${malformedHandshakes.map((e) => e.details || e.message).join('; ')}. This may indicate a TLS downgrade or stripping attack.`,
      recommendation: 'Enforce strict TLS version requirements. Enable HSTS with includeSubDomains. Investigate for MITM tools on the network path.',
    });
  }
}
