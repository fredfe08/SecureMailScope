import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { EvidenceReport } from '@/evidence';
import type { ThreatFinding } from '@/lib/fraudDetection';
import { formatNumber } from '@/evidence';

const PAGE_MARGIN = 50;
const PAGE_WIDTH = 595.28;
const PAGE_HEIGHT = 841.89;
const CONTENT_WIDTH = PAGE_WIDTH - PAGE_MARGIN * 2;
const BODY_FONT_SIZE = 11;
const HEADING_FONT_SIZE = 16;
const SUBHEADING_FONT_SIZE = 13;
const SMALL_FONT_SIZE = 9;

export function generatePdfReport(
  report: EvidenceReport,
  threats: ThreatFinding[],
  aiSummary: string | null
): void {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });

  let y = PAGE_MARGIN;

  y = drawHeader(doc, report, y);
  y += 20;

  if (aiSummary) {
    y = drawSection(doc, 'AI Summary', y, (doc, y) => {
      const lines = doc.splitTextToSize(aiSummary, CONTENT_WIDTH);
      doc.setFontSize(BODY_FONT_SIZE);
      doc.setTextColor(40, 40, 40);
      doc.setFont('helvetica', 'normal');
      let ly = y;
      for (const line of lines) {
        if (ly > PAGE_HEIGHT - PAGE_MARGIN - 30) {
          doc.addPage();
          ly = PAGE_MARGIN;
        }
        doc.text(line, PAGE_MARGIN, ly);
        ly += 16;
      }
      return ly;
    });
    y += 25;
  }

  y = drawSection(doc, 'Threat Detection Findings', y, (doc, y) => {
    if (threats.length === 0) {
      doc.setFontSize(BODY_FONT_SIZE);
      doc.setTextColor(40, 40, 40);
      doc.text('No threats detected.', PAGE_MARGIN, y);
      return y + 20;
    }

    autoTable(doc, {
      startY: y,
      head: [['Category', 'Severity', 'Evidence', 'Recommendation']],
      body: threats.map((t) => [t.category, t.severity, t.evidence, t.recommendation]),
      theme: 'grid',
      headStyles: { fillColor: [50, 50, 50], textColor: 255, fontSize: BODY_FONT_SIZE, fontStyle: 'bold' },
      bodyStyles: { fontSize: SMALL_FONT_SIZE, textColor: [40, 40, 40], cellPadding: 5 },
      columnStyles: {
        0: { cellWidth: 90, fontStyle: 'bold' },
        1: { cellWidth: 55 },
        2: { cellWidth: 180 },
        3: { cellWidth: CONTENT_WIDTH - 90 - 55 - 180 },
      },
      margin: { left: PAGE_MARGIN, right: PAGE_MARGIN },
    });

    return (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 20;
  });
  y += 25;

  y = drawSection(doc, 'Sessions', y, (doc, y) => {
    autoTable(doc, {
      startY: y,
      head: [['ID', 'Source', 'Destination', 'Protocol', 'Port', 'State', 'Events', 'Bytes']],
      body: report.sessions.map((s) => [
        s.id,
        s.source,
        s.destination,
        s.protocol,
        String(s.port),
        s.state,
        String(s.eventCount),
        formatNumber(s.bytesTransferred),
      ]),
      theme: 'grid',
      headStyles: { fillColor: [50, 50, 50], textColor: 255, fontSize: SMALL_FONT_SIZE, fontStyle: 'bold' },
      bodyStyles: { fontSize: SMALL_FONT_SIZE, textColor: [40, 40, 40], cellPadding: 4 },
      margin: { left: PAGE_MARGIN, right: PAGE_MARGIN },
    });

    return (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 20;
  });
  y += 25;

  y = drawSection(doc, 'STARTTLS Findings', y, (doc, y) => {
    autoTable(doc, {
      startY: y,
      head: [['Server', 'Port', 'Supported', 'Forced', 'State', 'Details']],
      body: report.starttlsFindings.map((f) => [
        f.server,
        String(f.port),
        f.supported ? 'Yes' : 'No',
        f.forced ? 'Yes' : 'No',
        f.state,
        f.details,
      ]),
      theme: 'grid',
      headStyles: { fillColor: [50, 50, 50], textColor: 255, fontSize: SMALL_FONT_SIZE, fontStyle: 'bold' },
      bodyStyles: { fontSize: SMALL_FONT_SIZE, textColor: [40, 40, 40], cellPadding: 4 },
      columnStyles: {
        5: { cellWidth: CONTENT_WIDTH - 70 - 35 - 50 - 40 - 50 },
      },
      margin: { left: PAGE_MARGIN, right: PAGE_MARGIN },
    });

    return (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 20;
  });
  y += 25;

  y = drawSection(doc, 'TLS & Certificate Findings', y, (doc, y) => {
    autoTable(doc, {
      startY: y,
      head: [['Server', 'Version', 'Cipher', 'Key Exchange', 'State', 'Details']],
      body: report.tlsFindings.map((f) => [
        f.server,
        f.version,
        f.cipher,
        f.keyExchange,
        f.state,
        f.details,
      ]),
      theme: 'grid',
      headStyles: { fillColor: [50, 50, 50], textColor: 255, fontSize: SMALL_FONT_SIZE, fontStyle: 'bold' },
      bodyStyles: { fontSize: SMALL_FONT_SIZE, textColor: [40, 40, 40], cellPadding: 4 },
      margin: { left: PAGE_MARGIN, right: PAGE_MARGIN },
    });

    return (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 15;
  });

  y += 10;
  y = drawSection(doc, 'Certificate Details', y, (doc, y) => {
    autoTable(doc, {
      startY: y,
      head: [['Hostname', 'Issuer', 'Subject', 'Validity', 'Key', 'State', 'Details']],
      body: report.certificates.map((c) => [
        c.hostname,
        c.issuer,
        c.subject,
        `${c.validFrom} to ${c.validTo}`,
        `${c.keyType} ${c.keyLength}b`,
        c.state,
        c.details,
      ]),
      theme: 'grid',
      headStyles: { fillColor: [50, 50, 50], textColor: 255, fontSize: SMALL_FONT_SIZE, fontStyle: 'bold' },
      bodyStyles: { fontSize: SMALL_FONT_SIZE, textColor: [40, 40, 40], cellPadding: 4 },
      margin: { left: PAGE_MARGIN, right: PAGE_MARGIN },
    });

    return (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 20;
  });
  y += 25;

  y = drawSection(doc, 'Appendix: Raw Evidence', y, (doc, y) => {
    autoTable(doc, {
      startY: y,
      head: [['Time', 'Source', 'Destination', 'Protocol', 'State', 'Message', 'Details', 'Bytes']],
      body: report.events.map((e) => [
        new Date(e.timestamp).toLocaleTimeString(),
        e.source,
        e.destination,
        e.protocol,
        e.state,
        e.message,
        e.details || '',
        e.bytes ? String(e.bytes) : '—',
      ]),
      theme: 'striped',
      headStyles: { fillColor: [50, 50, 50], textColor: 255, fontSize: SMALL_FONT_SIZE, fontStyle: 'bold' },
      bodyStyles: { fontSize: 8, textColor: [40, 40, 40], cellPadding: 3 },
      margin: { left: PAGE_MARGIN, right: PAGE_MARGIN },
    });

    return (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 20;
  });

  addPageNumbers(doc);

  const filename = `${report.caseLabel}_report.pdf`;
  doc.save(filename);
}

function drawHeader(doc: jsPDF, report: EvidenceReport, y: number): number {
  doc.setFillColor(30, 30, 30);
  doc.rect(0, 0, PAGE_WIDTH, 80, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(HEADING_FONT_SIZE);
  doc.text(`Case ${report.caseLabel} — Investigation Report`, PAGE_MARGIN, 35);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(BODY_FONT_SIZE);
  doc.setTextColor(200, 200, 200);
  doc.text(report.caseTitle, PAGE_MARGIN, 55);

  const genDate = new Date(report.generatedAt).toLocaleString();
  doc.text(`Generated: ${genDate}`, PAGE_MARGIN, 70);

  y = 105;
  doc.setTextColor(40, 40, 40);
  doc.setFontSize(BODY_FONT_SIZE);
  doc.setFont('helvetica', 'normal');
  doc.text(`Analyst: ${report.analyst}`, PAGE_MARGIN, y);
  doc.text(`Source File: ${report.sourceFile}`, PAGE_MARGIN + 250, y);
  y += 15;
  doc.setFont('helvetica', 'bold');
  doc.text('Executive Summary:', PAGE_MARGIN, y);
  y += 15;
  doc.setFont('helvetica', 'normal');
  const summaryLines = doc.splitTextToSize(report.summary, CONTENT_WIDTH);
  for (const line of summaryLines) {
    doc.text(line, PAGE_MARGIN, y);
    y += 14;
  }

  return y;
}

function drawSection(
  doc: jsPDF,
  title: string,
  y: number,
  renderContent: (doc: jsPDF, y: number) => number
): number {
  if (y > PAGE_HEIGHT - PAGE_MARGIN - 100) {
    doc.addPage();
    y = PAGE_MARGIN;
  }

  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(1);
  doc.line(PAGE_MARGIN, y - 5, PAGE_WIDTH - PAGE_MARGIN, y - 5);
  y += 10;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(SUBHEADING_FONT_SIZE);
  doc.setTextColor(30, 30, 30);
  doc.text(title, PAGE_MARGIN, y);
  y += 20;

  return renderContent(doc, y);
}

function addPageNumbers(doc: jsPDF): void {
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(SMALL_FONT_SIZE);
    doc.setTextColor(120, 120, 120);
    doc.text(
      `Page ${i} of ${pageCount}`,
      PAGE_WIDTH / 2,
      PAGE_HEIGHT - 20,
      { align: 'center' }
    );
    doc.text(
      `Case SIH26159 — Confidential`,
      PAGE_MARGIN,
      PAGE_HEIGHT - 20
    );
  }
}
